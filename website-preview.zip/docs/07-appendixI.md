---
title: Appendix I
---



# Appendix I: Ontologies, Vocabularies, Taxonomies, and Standards

## SNOMED

## ICD10

## RxNorm

## LOINC

## Emerging standards such as FHIR

## OMOP
